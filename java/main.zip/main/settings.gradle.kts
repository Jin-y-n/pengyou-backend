rootProject.name = "main"
include("common")
include("global-processing")
include("service-user")
include("service-admin")


