package com.pengyou;


/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 2024/7/28 上午11:15
    @Description: 

*/

import com.pengyou.exception.BaseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ServiceAdmin {


    public static void main(String[] args) {
        SpringApplication.run(ServiceAdmin.class, args);
    }
}