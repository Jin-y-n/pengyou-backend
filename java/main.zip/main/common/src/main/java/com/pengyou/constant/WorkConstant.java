package com.pengyou.constant;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class WorkConstant {
    public static final String MEMBER_CONFIRM_CODE_INVALID = "地址无效";

    private WorkConstant() {}
}
