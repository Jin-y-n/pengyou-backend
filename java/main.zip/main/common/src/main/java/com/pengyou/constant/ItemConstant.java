package com.pengyou.constant;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class ItemConstant {
    public static final String ITEM_STATUS_EXCEPTION = "物品状态异常";

    private ItemConstant() {}
}
