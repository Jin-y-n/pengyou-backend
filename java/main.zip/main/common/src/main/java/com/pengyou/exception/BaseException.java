package com.pengyou.exception;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class BaseException extends RuntimeException {

    public BaseException() {
    }

    public BaseException(String msg) {
        super(msg);
    }
}
