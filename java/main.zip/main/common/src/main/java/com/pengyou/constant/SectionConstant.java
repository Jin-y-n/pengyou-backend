package com.pengyou.constant;

public class SectionConstant {
    public static final String SECTION_ADD_SUCCESS = "分区添加成功";
    public static final String SECTION_ADD_FAILED = "分区添加失败";
    public static final String SECTION_EXISTS = "分区已存在";
    public static final String SECTION_UPDATE_SUCCESS = "分区修改成功";
    public static final String SECTION_UPDATE_FAILED = "分区修改失败";
    public static final String SECTION_DELETE_FAILED = "分区删除失败";
    public static final String SECTION_DELETE_SUCCESS = "分区删除成功";

}
