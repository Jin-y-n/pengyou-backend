package com.pengyou.util.storage;



/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 8/15/24
    @Description: 

*/


public class DBClient {
}
