package com.pengyou.constant;
/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 2024/7/22 上午17:31
    @Description: 

*/

public class CommentConstant {


    public static final String COMMENT_SUCCESS = "评论成功";
    public static final String COMMENT_UPDATE_SUCCESS = "评论更新成功";
    public static final String COMMENT_DELETE_SUCCESS = "评论删除成功";

    private CommentConstant () {}
}
