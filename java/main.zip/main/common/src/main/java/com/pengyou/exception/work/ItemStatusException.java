package com.pengyou.exception.work;

import com.pengyou.exception.BaseException;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class ItemStatusException extends BaseException {
    public ItemStatusException(String msg) {
        super(msg);
    }
}
