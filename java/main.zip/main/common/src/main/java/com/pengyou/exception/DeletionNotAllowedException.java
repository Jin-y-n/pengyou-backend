package com.pengyou.exception;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class DeletionNotAllowedException extends BaseException {

    public DeletionNotAllowedException(String msg) {
        super(msg);
    }

}
