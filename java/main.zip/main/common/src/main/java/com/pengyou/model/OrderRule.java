package com.pengyou.model;
/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 2024/7/25 上午16:24
    @Description: 

*/

public enum OrderRule {
    DESC, ASC
}
