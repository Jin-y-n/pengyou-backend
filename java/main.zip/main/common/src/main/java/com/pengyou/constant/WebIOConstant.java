package com.pengyou.constant;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class WebIOConstant {

    public static final String INPUT_INVALID = "输入不合法";

    private WebIOConstant() {}
}
