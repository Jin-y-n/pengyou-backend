package com.pengyou.exception;

/*
 * Author: Napbad
 * Version: 1.0
 */
public class UserNotLoginException extends BaseException {

    public UserNotLoginException() {
    }

    public UserNotLoginException(String msg) {
        super(msg);
    }

}
