package com.pengyou.controller;

import com.pengyou.model.Result;
import com.pengyou.model.dto.post.UserPostForAdd;
import com.pengyou.model.dto.post.UserPostForDelete;
import com.pengyou.model.dto.post.UserPostForQuery;
import com.pengyou.model.dto.post.UserPostForUpdate;
import com.pengyou.service.PostService;
import com.pengyou.util.UserContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.babyfish.jimmer.client.meta.Api;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@Api
@Slf4j
@CrossOrigin
@RestController
@RequiredArgsConstructor
@RequestMapping("/user/post")
public class PostController {
    private final PostService postService;

    @Api
    @PostMapping("/add")
    public Result addPost(
            @RequestBody UserPostForAdd userPostForAdd
    ) {
        postService.addPost(userPostForAdd);
        log.info("User: [" + UserContext.getUserId()+"] add Post at " + new Date());
        return Result.success("Post添加成功");
    }

    @Api
    @PostMapping("/delete")
    public Result deletePost(
            @RequestBody UserPostForDelete userPostForDelete
    ) {
        postService.deletePost(userPostForDelete);
        log.info("User: [" + UserContext.getUserId() + "] delete Post: [" + userPostForDelete.getIds() + "] at " + new Date());
        return Result.success("Post删除成功");
    }

    @Api
    @PostMapping("/update")
    public Result updatePost(
            @RequestBody UserPostForUpdate userPostForUpdate
    ) {
        postService.updatePost(userPostForUpdate);
        log.info("User: [" + UserContext.getUserId() + "] update Post: [" + userPostForUpdate.getId() + "] at " + new Date());
        return Result.success("Post更新成功");
    }

    @Api
    @PostMapping("/query")
    public Result queryPost(
            @RequestBody UserPostForQuery userPostForQuery
    ) {
        log.info("User: [" + UserContext.getUserId() + "] query Post: [" + userPostForQuery + "] at " + new Date());
        return Result.success("Post查询成功", postService.queryPost(userPostForQuery));
    }
}