package com.pengyou;


/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 2024/7/28 上午10:37
    @Description: 

*/


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceUser {
    public static void main(String[] args) {
        SpringApplication.run(ServiceUser.class, args);
    }
}