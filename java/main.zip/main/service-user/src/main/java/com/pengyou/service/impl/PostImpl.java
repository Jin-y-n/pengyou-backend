package com.pengyou.service.impl;

import com.pengyou.constant.AccountConstant;
import com.pengyou.exception.BaseException;
import com.pengyou.model.dto.post.*;
import com.pengyou.model.entity.PostTable;
import com.pengyou.service.PostService;
import com.pengyou.util.RedisLock;
import com.pengyou.util.UserContext;
import lombok.RequiredArgsConstructor;
import org.babyfish.jimmer.Page;
import org.babyfish.jimmer.sql.JSqlClient;
import org.babyfish.jimmer.sql.ast.Predicate;
import org.babyfish.jimmer.sql.ast.query.TypedSubQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PostImpl implements PostService {
    private final JSqlClient sqlClient;
    private final PostTable postTable = PostTable.$;
    private final RedisLock redisLock;

    @Transactional
    @Override
    public void addPost(UserPostForAdd userPostForAdd) {
        redisLock.lock();
        boolean exists = sqlClient
                .createQuery(postTable)
                .where(
                        Predicate.and(
                                postTable.title().eq(userPostForAdd.getTitle()),
                                postTable.content().eq(userPostForAdd.getContent())
//                                postTable.labels(labels -> {
//                                            return labels.label().in(
//                                                    userPostForAdd.getLabels().stream()
//                                                            .map(table -> String.valueOf(table.getId()))
//                                                            .toList());
//                                        }
//                                )
                        )
                ).select(postTable.id())
                .exists();
        if (exists) {
            throw new BaseException("该帖子已存在");
        }

        sqlClient
                .insert(userPostForAdd);
        redisLock.unlock();
    }

    @Override
    public void updatePost(UserPostForUpdate userPostForUpdate) {
        redisLock.lock();
        if (UserContext.getUserId().longValue() != userPostForUpdate.getAuthorId()) {
            throw new BaseException(AccountConstant.INSUFFICIENT_AUTHORITY);
        }
        sqlClient
                .update(userPostForUpdate);
        redisLock.unlock();
    }

    @Override
    public void deletePost(UserPostForDelete userPostForDelete) {
        sqlClient
                .createDelete(postTable)
                .where(
                        Predicate.and(
                                postTable.id().in(userPostForDelete.getIds()),
                                postTable.author().id().eq(Long.valueOf(UserContext.getUserId()))
                        )
                )
                .execute();
    }

    @Override
    public Page<UserPostForQueryView> queryPost(UserPostForQuery userPostForQuery) {
        Page<UserPostForQueryView> page = sqlClient
                .createQuery(postTable)
                .where(userPostForQuery)
                .select(
                        postTable.fetch(UserPostForQueryView.class)
                )
                .fetchPage(userPostForQuery.getPageIndex(), userPostForQuery.getPageSize());

        if (page.getTotalRowCount() == 0) {
            throw new BaseException("Post不存在");
        }
        return page;
    }

}
