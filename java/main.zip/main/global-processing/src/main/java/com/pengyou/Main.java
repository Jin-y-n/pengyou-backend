package com.pengyou;



/*
    @Author: Napbad
    @Version: 0.1    
    @Date: 8/15/24
    @Description: 

*/

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}